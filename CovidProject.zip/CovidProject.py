# Deshagra Paranahewa COVID-19 Data Project
import pandas as pd
import streamlit as st
import plotly.express as px

st.write("""
# COVID-19 Case Instances Visualization

Shown are the COVID-19 **daily new cases** and **total confirmed cases** for a selected country!

""")

# Load COVID-19 data from the Johns Hopkins University repository
data_url = 'https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv'
covid_data = pd.read_csv(data_url)

# Create a list of countries available in the dataset
countries = covid_data['Country/Region'].unique()

# Create a selectbox to choose a country
selected_country = st.selectbox('Select a country:', countries)

# Filter data for the selected country
country_data = covid_data[covid_data['Country/Region'] == selected_country]

# Get daily new cases and total confirmed cases for the selected country
daily_new_cases = country_data.iloc[:, 4:].diff(axis=1).fillna(0).sum().astype(int)
total_confirmed_cases = country_data.iloc[:, 4:].sum().astype(int)

# Convert data to a DataFrame with dates as a separate column
daily_new_cases_df = pd.DataFrame({'Date': daily_new_cases.index, 'Daily New Cases': daily_new_cases.values})
total_confirmed_cases_df = pd.DataFrame({'Date': total_confirmed_cases.index, 'Total Confirmed Cases': total_confirmed_cases.values})

# Create interactive line charts with Plotly
fig1 = px.line(daily_new_cases_df, x='Date', y='Daily New Cases', title = 'Daily New Cases')
fig2 = px.line(total_confirmed_cases_df, x='Date', y='Total Confirmed Cases', title = 'Total Confirmed Cases')

# Display the charts
st.plotly_chart(fig1)
st.plotly_chart(fig2)
